# صدى sada — Video Bundle

5 apps × 3 languages = 15 HTML files
Price: €4.99

🔗 https://abourdim.github.io/sada
🌐 workshop-diy.org
📍 Association Loi 1901 · Chelles 77500

## Apps included
- workshop-diy-hacker-presentation
- workshop-diy-genius-video
- workshop-diy-wrapped-2025
- workshop-diy-breaking-news
- workshop-diy-app-demo-reel

## How to use
Open any .html file in Chrome. No install needed.
- Root files: English
- fr/ folder: French
- ar/ folder: Arabic (RTL)

*صدى sada · v4.0 · March 2026*

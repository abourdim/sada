# صدى sada — Tools Bundle

14 apps × 3 languages = 42 HTML files
Price: €9.99

🔗 https://abourdim.github.io/sada
🌐 workshop-diy.org
📍 Association Loi 1901 · Chelles 77500

## Apps included
- workshop-diy-live-monitor
- workshop-diy-github-profile
- workshop-diy-blueprints
- workshop-diy-periodic-table
- workshop-diy-testimonials
- workshop-diy-sticker-sheet
- workshop-diy-linkedin
- workshop-diy-nasa-control
- workshop-diy-social-media-kit
- workshop-diy-genius-ideas-lab
- workshop-diy-weather
- workshop-diy-cookbook
- workshop-diy-newspaper
- workshop-diy-wanted-wall

## How to use
Open any .html file in Chrome. No install needed.
- Root files: English
- fr/ folder: French
- ar/ folder: Arabic (RTL)

*صدى sada · v4.0 · March 2026*

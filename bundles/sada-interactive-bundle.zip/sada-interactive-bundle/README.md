# صدى sada — Interactive Bundle

10 apps × 3 languages = 30 HTML files
Price: €7.99

🔗 https://abourdim.github.io/sada
🌐 workshop-diy.org
📍 Association Loi 1901 · Chelles 77500

## Apps included
- workshop-diy-hacker-terminal
- workshop-diy-os-desktop
- workshop-diy-discord-chat
- workshop-diy-network-map
- workshop-diy-classified-dossier
- workshop-diy-app-store
- workshop-diy-reddit
- workshop-diy-trial
- workshop-diy-departures
- workshop-diy-space-mission

## How to use
Open any .html file in Chrome. No install needed.
- Root files: English
- fr/ folder: French
- ar/ folder: Arabic (RTL)

*صدى sada · v4.0 · March 2026*

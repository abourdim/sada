# صدى sada — Games Bundle

12 apps × 3 languages = 36 HTML files
Price: €8.99

🔗 https://abourdim.github.io/sada
🌐 workshop-diy.org
📍 Association Loi 1901 · Chelles 77500

## Apps included
- workshop-diy-arcade
- workshop-diy-ctf-quiz
- workshop-diy-card-collection
- workshop-diy-skill-tree
- workshop-diy-escape-room
- workshop-diy-pokedex
- workshop-diy-app-match
- workshop-diy-zodiac
- workshop-diy-bingo
- workshop-diy-rap-battle
- workshop-diy-slot-machine
- workshop-diy-flappy

## How to use
Open any .html file in Chrome. No install needed.
- Root files: English
- fr/ folder: French
- ar/ folder: Arabic (RTL)

*صدى sada · v4.0 · March 2026*

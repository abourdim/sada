# صدى sada — Ambient Bundle

5 apps × 3 languages = 15 HTML files
Price: €3.99

🔗 https://abourdim.github.io/sada
🌐 workshop-diy.org
📍 Association Loi 1901 · Chelles 77500

## Apps included
- workshop-diy-ambient-screen
- workshop-diy-synth-visualizer
- workshop-diy-boot-sequence
- workshop-diy-creepypasta
- workshop-diy-loading-screens

## How to use
Open any .html file in Chrome. No install needed.
- Root files: English
- fr/ folder: French
- ar/ folder: Arabic (RTL)

*صدى sada · v4.0 · March 2026*
